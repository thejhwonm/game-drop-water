java-libgdx-drop-example
========================

The libGDX example application "Drop" from https://github.com/libgdx/libgdx/wiki/A-simple-game
